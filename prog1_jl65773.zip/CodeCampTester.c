#include<stdio.h>
#include<stdbool.h>

// CodeCampTester.c -- EE 312 Project 1 -- Tester class

/* Program author: Justine Le
 * Date: 8/29/2019
 * Brief description: practice test data for EE312 HW 1.
 */

/* Student information for assignment:
 * 
 * Name: Justine Le
 * email address: justinele99@utexas.edu
 * UTEID: JL65773
 * Section 5 digit ID: 16015
 *  
 */

//function prototypes. These will be completed in CodeCamp.c
int hammingDistance(int aList[], int bList[], int len);
int sum3or5Multiples();
bool lastDigit(int num1, int num2);
int reverseInt(int num); 
//****************************

int main() {
    int expected, actual;

    // test 1A, hammingDistance
    int h1a[] = {5, 6, 3, 4, 2, 1};
    int h2a[] = {5, 6, 3, 4, 2, 1};
    expected = 0;
    actual = hammingDistance(h1a, h2a, 6);
    printf("Test 1A hamming distance: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
       printf("passed test 1A, hamming distance\n\n");
    else
       printf("**** FAILED **** test 1A, hamming distance\n\n");

    // test 1B, hammingDistance
    int h1b[] = {3, 4, 5, 6, 7, 8, 9};
    int h2b[] = {5, 4, 9, 6, 8, 8, 0};
    expected = 4;
    actual = hammingDistance(h1b, h2b, 7);
    printf("Test 1B hamming distance: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 1B, hamming distance\n\n");
    else
        printf("**** FAILED **** test 1B, hamming distance\n\n");

    // test 2A, last digit
    int n1 = -123;
    int n2 = 124;
    expected = false;
    actual = lastDigit(n1, n2);
    printf("Test 2A last digit: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
       printf("passed test 2A, last digit\n\n");
    else
       printf("**** FAILED **** test 2A, last digit\n\n");

    // test 2B, last digit
    n1 = 456;
    n2 = -756;
    expected = true;
    actual = lastDigit(n1, n2);
    printf("Test 2B last digit: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
      printf("passed test 2B, last digit\n\n");
    else
       printf("**** FAILED **** test 2B, last digit\n\n");

    // test 3, sum of multiples of 3 or 5
    expected = 233168;
    actual = sum3or5Multiples();
    printf("Test 3 sum of multiples: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
       printf("passed test 3, sum of multiples of 3 or 5\n\n");
    else
       printf("**** FAILED **** test 3, sum of multiples of 3 or 5\n\n");

    // test 4A, reverse int
    int n4 = -123;
    expected = -321;
    actual = reverseInt(n4);
    printf("Test 4A reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
       printf("passed test 4A, reverse int\n\n");
    else
       printf("**** FAILED **** test 4A, reverse int\n\n");

    // test 4B, reverse int
    n4 = 1020;
    expected = 201;
    actual = reverseInt(n4);
    printf("Test 4B reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
       printf("passed test 4B, reverse int\n\n");
    else
       printf("**** FAILED **** test 4B, reverse int\n\n");

}
